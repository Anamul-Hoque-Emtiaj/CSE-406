# diva-apk-file
DIVA (Damn insecure and vulnerable App) is an App intentionally designed to be insecure
## What is Diva App ? 
  DIVA (Damn insecure and vulnerable App) is an App intentionally designed to be insecure. We are releasing the Android version of Diva. We thought it would be a nice way to start the year by contributing something to the security community. The aim of the App is to teach developers/QA/security professionals, flaws that are generally present in the Apps due poor or insecure coding practices. If you are reading this, you want to either learn App pentesting or secure coding and I sincerely hope that DIVA solves your purpose. So, sit back and enjoy the ride. 
## How To install Diva App ? 
  * -1 Download the apk file to your computer
      - If You Have "git" ? Then You Can Execute This Command -> ``` git clone https://github.com/xAltmime/diva-apk-file.git``` 
      
  * -2 Install apk via adb
      - Command to install in adb : ``` adb install DivaApplication.apk ```
        - If You Have Nox Player application ?
          * Then You Have ADB File in Path Nox Player : ``` C:\Program Files\Nox\bin\nox_adb.exe ```
